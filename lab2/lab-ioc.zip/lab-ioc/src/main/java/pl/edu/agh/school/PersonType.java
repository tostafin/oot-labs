package pl.edu.agh.school;

public enum PersonType {
	Teacher,
	Student
}
