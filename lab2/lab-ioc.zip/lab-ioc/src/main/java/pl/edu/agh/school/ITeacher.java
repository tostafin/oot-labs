package pl.edu.agh.school;

public interface ITeacher {

}
